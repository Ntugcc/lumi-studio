@echo off
rem ============================================================================
rem  install.bat - put Lumi Studio on this machine.
rem
rem  Copies the program to %LOCALAPPDATA%\LumiStudio, adds a Start Menu entry,
rem  and makes .lumi files open in the editor.
rem
rem  Everything it touches is under the current user, so it needs no administrator
rem  rights and can be undone by running uninstall.bat.
rem ============================================================================
setlocal
set "HERE=%~dp0"
set "TARGET=%LOCALAPPDATA%\LumiStudio"

echo.
echo   Installing Lumi Studio
echo   ----------------------
echo   from %HERE%
echo   to   %TARGET%
echo.

if not exist "%HERE%lumistudio.exe" (
    echo   lumistudio.exe is not next to this script.
    echo   Run install.bat from inside the folder it came in.
    echo.
    pause
    exit /b 1
)

if not exist "%TARGET%" mkdir "%TARGET%"
if errorlevel 1 (
    echo   Could not create %TARGET%
    echo.
    pause
    exit /b 1
)

xcopy /y /q /e "%HERE%*" "%TARGET%\" >nul
if errorlevel 1 (
    echo   Could not copy the files.
    echo.
    pause
    exit /b 1
)

rem --- Start Menu entry ------------------------------------------------------
set "MENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Lumi Studio"
if not exist "%MENU%" mkdir "%MENU%"

powershell -NoProfile -Command ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%MENU%\Lumi Studio.lnk'); $s.TargetPath='%TARGET%\lumistudio.exe'; $s.WorkingDirectory='%TARGET%'; $s.Description='Lumi Studio editor'; $s.Save()"

rem --- .lumi association ------------------------------------------------------
rem Written under HKCU so no administrator is needed. The association points at
rem the editor, which is the only sensible thing to do with a .lumi file.
reg add "HKCU\Software\Classes\.lumi" /ve /d "Lumi.Source" /f >nul
reg add "HKCU\Software\Classes\Lumi.Source" /ve /d "Lumi source file" /f >nul
reg add "HKCU\Software\Classes\Lumi.Source\DefaultIcon" /ve /d "\"%TARGET%\lumistudio.exe\",0" /f >nul
reg add "HKCU\Software\Classes\Lumi.Source\shell\open\command" /ve /d "\"%TARGET%\lumistudio.exe\" \"%%1\"" /f >nul

echo   Done.
echo.
echo   Lumi Studio is in the Start Menu.
echo   .lumi files will open in it.
echo.
echo   To remove it again, run uninstall.bat from this folder.
echo.
pause
endlocal
