# =============================================================================
#  scripts/install.ps1
#
#  Installs Lumi Studio for the current user.
#
#  Everything it touches lives under the user's own profile -- the program folder,
#  the Start Menu entry and the .lumi file association -- so it needs no
#  administrator rights and uninstall.ps1 undoes all of it.
#
#  Why this exists alongside install.bat
#  -------------------------------------
#  The batch file is what ships in the release folder, because a .bat is the one
#  thing a person can double-click without thinking about execution policy. This
#  script is the same operation with arguments, so the install location can be
#  chosen and so the whole thing can be tested without touching a real profile.
#
#  Kept pure ASCII for the reason recorded in build.ps1: PowerShell 5.1 reads a
#  script using the console code page.
#
#  Usage:
#      powershell -ExecutionPolicy Bypass -File scripts\install.ps1
#      powershell -ExecutionPolicy Bypass -File scripts\install.ps1 -Quiet
# =============================================================================

[CmdletBinding()]
param(
    # Where to install. Defaults to the per-user location.
    [string] $Target,

    # Where to put the Start Menu entry. Empty means the usual place.
    [string] $StartMenu,

    # Write the file association. Needs no administrator, but can be skipped.
    [switch] $NoAssociation,

    # Suppress the progress output.
    [switch] $Quiet
)

$ErrorActionPreference = 'Stop'

$Root   = Split-Path -Parent $PSScriptRoot
$Source = Join-Path $Root 'build\bin'

if (-not $Target)     { $Target = Join-Path $env:LOCALAPPDATA 'LumiStudio' }
if (-not $StartMenu)  { $StartMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Lumi Studio' }

function Say($text) { if (-not $Quiet) { Write-Host $text } }

Say ''
Say '  Installing Lumi Studio'
Say '  ----------------------'
Say "  from $Source"
Say "  to   $Target"

# -----------------------------------------------------------------------------
#  Check what we are installing
# -----------------------------------------------------------------------------
foreach ($needed in 'lumi.exe', 'lumistudio.exe') {
    if (-not (Test-Path (Join-Path $Source $needed))) {
        throw "$needed is not in $Source -- build the project first"
    }
}

# -----------------------------------------------------------------------------
#  Copy the program
# -----------------------------------------------------------------------------
if (Test-Path $Target) {
    # Replacing an existing install: clear the executables, so a stale one cannot
    # be left behind and run by mistake.
    Get-ChildItem $Target -Filter '*.exe' -ErrorAction SilentlyContinue | Remove-Item -Force
} else {
    New-Item -ItemType Directory -Force -Path $Target | Out-Null
}

foreach ($name in 'lumi.exe', 'lumistudio.exe') {
    Copy-Item (Join-Path $Source $name) $Target -Force
    Say "  installed $name"
}

# Examples, so the editor has something to open.
$exampleSource = Join-Path $Root 'examples'
if (Test-Path $exampleSource) {
    $exampleTarget = Join-Path $Target 'examples'
    New-Item -ItemType Directory -Force -Path $exampleTarget | Out-Null
    Copy-Item (Join-Path $exampleSource '*.lumi') $exampleTarget -Force
    $count = (Get-ChildItem $exampleTarget -Filter '*.lumi' | Measure-Object).Count
    Say "  installed $count examples"
}

# -----------------------------------------------------------------------------
#  Start Menu entry
# -----------------------------------------------------------------------------
New-Item -ItemType Directory -Force -Path $StartMenu | Out-Null

$shortcutPath = Join-Path $StartMenu 'Lumi Studio.lnk'
$shell = New-Object -ComObject WScript.Shell
$link = $shell.CreateShortcut($shortcutPath)
$link.TargetPath       = Join-Path $Target 'lumistudio.exe'
$link.WorkingDirectory = $Target
$link.Description      = 'Lumi Studio editor'
$link.IconLocation     = (Join-Path $Target 'lumistudio.exe') + ',0'
$link.Save()

Say "  Start Menu entry: $shortcutPath"

# -----------------------------------------------------------------------------
#  File association
#
#  Written under HKCU, which is why no administrator is needed. The editor is the
#  sensible thing to open a .lumi file with, so that is what it points at.
# -----------------------------------------------------------------------------
if (-not $NoAssociation) {
    $editor = Join-Path $Target 'lumistudio.exe'

    New-Item -Path 'HKCU:\Software\Classes\.lumi' -Force | Out-Null
    Set-ItemProperty -Path 'HKCU:\Software\Classes\.lumi' -Name '(default)' -Value 'Lumi.Source'

    New-Item -Path 'HKCU:\Software\Classes\Lumi.Source' -Force | Out-Null
    Set-ItemProperty -Path 'HKCU:\Software\Classes\Lumi.Source' -Name '(default)' -Value 'Lumi source file'

    New-Item -Path 'HKCU:\Software\Classes\Lumi.Source\DefaultIcon' -Force | Out-Null
    Set-ItemProperty -Path 'HKCU:\Software\Classes\Lumi.Source\DefaultIcon' -Name '(default)' -Value "$editor,0"

    New-Item -Path 'HKCU:\Software\Classes\Lumi.Source\shell\open\command' -Force | Out-Null
    Set-ItemProperty -Path 'HKCU:\Software\Classes\Lumi.Source\shell\open\command' -Name '(default)' -Value "`"$editor`" `"%1`""

    Say '  .lumi files now open in the editor'
}

Say ''
Say '  Done.'
Say ''
