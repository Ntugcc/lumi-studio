@echo off
rem ============================================================================
rem  uninstall.bat - undo what install.bat did.
rem
rem  Removes the program folder, the Start Menu entry and the file association.
rem  Nothing outside the current user's own settings is touched.
rem ============================================================================
setlocal
set "TARGET=%LOCALAPPDATA%\LumiStudio"
set "MENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Lumi Studio"

echo.
echo   Removing Lumi Studio
echo.

if exist "%MENU%" rd /s /q "%MENU%"
echo   Start Menu entry removed.

reg delete "HKCU\Software\Classes\.lumi" /f >nul 2>&1
reg delete "HKCU\Software\Classes\Lumi.Source" /f >nul 2>&1
echo   .lumi association removed.

if exist "%TARGET%" rd /s /q "%TARGET%"
echo   Program folder removed.

echo.
echo   Done.
echo.
pause
endlocal
