Lumi Studio 0.1.0
==================

A small language, its compiler, and an editor.

Getting started
---------------
    Double-click lumistudio.exe

    The editor opens with a sample program already in it.
    Press Ctrl+Enter to run it.

What is in this folder
----------------------
    lumistudio.exe    the editor
    lumi.exe          the compiler, which the editor runs for you
    examples\         programs to try
    README.md         how it was built and what was learned

Using the compiler on its own
-----------------------------
    lumi check  program.lumi              report problems without running
    lumi run    program.lumi              run it on the virtual machine
    lumi build  program.lumi --output=x   compile to a real .exe

If you want Lumi Studio in the Start Menu and .lumi files to open in it,
run install.bat instead of copying this folder about.
