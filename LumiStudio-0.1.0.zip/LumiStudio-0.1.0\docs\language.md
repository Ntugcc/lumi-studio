# The Lumi language

A short reference. Everything here is implemented; anything not here is not.

---

## A program

Every program needs a `main` that returns `i64`. That value becomes the process
exit status.

```lumi
fn main() -> i64 {
    print("hello")
    return 0
}
```

Statements are separated by newlines. A semicolon also works, and is needed only
when two statements share a line.

---

## Values and types

| Type | What it holds | Literals |
|---|---|---|
| `i64` | a 64-bit signed integer | `42`, `-7`, `0xFF`, `0b1010`, `1_000_000` |
| `f64` | a 64-bit float | `3.14`, `1.0e-9` |
| `bool` | true or false | `true`, `false` |
| `str` | text, UTF-8 | `"hello"`, `"line\nbreak"` |
| `unit` | nothing | what a statement or an assignment produces |

There are no implicit conversions between numeric types. `1 + 1.0` is an error;
write `1.0 + 1.0`.

---

## Bindings

```lumi
let x = 10          // immutable
var y = 0           // mutable and reassignable

let name: str = "Lumi"   // the type can be written out
```

`let` cannot be reassigned; trying is a compile error rather than something that
fails at run time.

Compound assignment exists for the arithmetic operators and for strings:

```lumi
var n = 5
n += 2      // 7
n *= 3      // 21

var s = "a"
s += "b"    // "ab"
```

---

## Functions

```lumi
fn add(a: i64, b: i64) -> i64 {
    return a + b
}
```

Parameter and return types are always written. At most four parameters can be
passed in registers by the native backend, which is the current limit.

A function whose work is finished can return early:

```lumi
fn sign(n: i64) -> i64 {
    if n < 0 { return -1 }
    if n > 0 { return 1 }
    return 0
}
```

---

## Operators

From tightest to loosest:

| | |
|---|---|
| unary | `-` `not` |
| multiplicative | `*` `/` `%` |
| additive | `+` `-` |
| comparison | `==` `!=` `<` `<=` `>` `>=` |
| logical | `and` `or` |

`and` and `or` short-circuit: the right side is not evaluated when the left
already decides the answer. That is a guarantee, not an optimisation -- it is how
you write a bounds check before an index.

`+` concatenates when both sides are `str` and adds when they are numbers. The
operand type decides, so `"a" + "b"` and `1 + 2` are both correct and neither
needs a different operator.

---

## Conditionals

`if` is an expression, so it produces a value:

```lumi
let label = if n < 0 { "negative" } else { "not negative" }
```

An `if` used as a value needs an `else`, because otherwise there would be nothing
to produce when the condition is false. An `if` used as a statement does not.

```lumi
if n < 0 {
    print("negative")
} else if n == 0 {
    print("zero")
} else {
    print("positive")
}
```

---

## Loops

```lumi
var i = 0
while i < 10 {
    print(i64_to_str(i))
    i = i + 1
}
```

`break` leaves the loop; `continue` skips the rest of the body and tests the
condition again. Both apply to the innermost enclosing loop.

A `while true` loop with a `break` inside is the usual way to write "repeat until
something happens".

---

## Strings

A `str` is text. Concatenate with `+`, and convert other values with the built-in
functions:

```lumi
print("the answer is " + i64_to_str(42))
print("pi is about " + f64_to_str(3.14159))
print("that is " + bool_to_str(true))
```

Escape sequences inside a string literal:

| | |
|---|---|
| `\n` | newline |
| `\t` | tab |
| `\\` | backslash |
| `\"` | a double quote |
| `\u{1F600}` | a Unicode code point |

Strings compare with `==` and `!=` by their contents, not by identity.

---

## Printing

`print` takes one value of any type and writes it followed by a newline:

```lumi
print("text")
print(42)
print(true)
print(3.14)
```

Anything that is not already a `str` has to be converted first, which is why the
`*_to_str` functions exist.

---

## Comments

```lumi
// to the end of the line
```

---

## Where the two back ends differ

`lumi run` interprets the program on a virtual machine. `lumi build` compiles it
to x86-64 assembly and produces a real executable. Both are checked by the same
front end, so both accept exactly the same programs.

The native back end currently implements integers and strings. Floating point
works on the virtual machine only; `lumi build` reports an error if it is needed.
`lumi run` is therefore the better choice while working something out.

---

## Errors

Diagnostics are the part of this project that received the most attention. A
mistake is reported with its position, the relevant source line, and -- where the
cause is guessable -- a note saying what was probably meant:

```
error[L0311]: operator 'add' cannot be applied to str and i64
  --> program.lumi:7:11
   |
   |     print("count: " + 42)
   |                      ^ cannot add str and i64
   |
   `- help: convert the number first, as in i64_to_str(42)
```
