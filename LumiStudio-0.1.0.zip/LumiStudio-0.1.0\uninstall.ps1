# =============================================================================
#  scripts/uninstall.ps1
#
#  Undoes install.ps1: removes the program folder, the Start Menu entry and the
#  file association.
#
#  Nothing outside the current user's own settings is touched, which is what makes
#  an install with no administrator rights reversible with no administrator
#  rights.
#
#  Usage:
#      powershell -ExecutionPolicy Bypass -File scripts\uninstall.ps1
#      powershell -ExecutionPolicy Bypass -File scripts\uninstall.ps1 -NoAssociation
# =============================================================================

[CmdletBinding()]
param(
    [string] $Target,
    [string] $StartMenu,

    # Leave the .lumi association alone.
    [switch] $NoAssociation,

    [switch] $Quiet
)

$ErrorActionPreference = 'Stop'

if (-not $Target)    { $Target    = Join-Path $env:LOCALAPPDATA 'LumiStudio' }
if (-not $StartMenu) { $StartMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Lumi Studio' }

function Say($text) { if (-not $Quiet) { Write-Host $text } }

Say ''
Say '  Removing Lumi Studio'
Say ''

# -----------------------------------------------------------------------------
#  Start Menu
# -----------------------------------------------------------------------------
if (Test-Path $StartMenu) {
    Remove-Item -Recurse -Force $StartMenu
    Say "  removed $StartMenu"
} else {
    Say '  no Start Menu entry to remove'
}

# -----------------------------------------------------------------------------
#  File association
#
#  Only the keys this installer created. A different program that has since taken
#  over .lumi keeps its own keys, because they are not ours to delete.
# -----------------------------------------------------------------------------
if (-not $NoAssociation) {
    foreach ($key in 'HKCU:\Software\Classes\.lumi', 'HKCU:\Software\Classes\Lumi.Source') {
        if (Test-Path $key) {
            Remove-Item -Recurse -Force $key
            Say "  removed $key"
        }
    }
}

# -----------------------------------------------------------------------------
#  Program folder
# -----------------------------------------------------------------------------
if (Test-Path $Target) {
    # Refuse to delete something that is plainly not our folder, rather than
    # trusting the argument. A mistyped path here would be unrecoverable.
    $editor = Join-Path $Target 'lumistudio.exe'
    $compiler = Join-Path $Target 'lumi.exe'

    if ((Test-Path $editor) -or (Test-Path $compiler)) {
        Remove-Item -Recurse -Force $Target
        Say "  removed $Target"
    } else {
        Say "  left $Target alone: it does not look like a Lumi Studio folder"
    }
} else {
    Say '  no program folder to remove'
}

Say ''
Say '  Done.'
Say ''
