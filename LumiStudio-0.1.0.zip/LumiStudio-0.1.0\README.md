# The Lumi compiler

A compiler for a small statically typed language, written from scratch in **C++20**.

This is not a "type along with the tutorial" project. The language itself is
designed here, and every layer of the compiler -- lexing, parsing, semantic
analysis, bytecode, the virtual machine, target code generation -- is written
by hand.

## Status

| Milestone | Content | State |
|---|---|---|
| **M0** | Project skeleton and diagnostics | ✅ **done** |
| **M1a** | Lexer | ✅ **done** |
| **M1b** | Parser and syntax tree | ✅ **done** |
| **M1c** | Semantic analysis (symbols, types) | ✅ **done** |
| **M2** | Bytecode generation and a stack VM | ✅ **done** |
| **M3** | x86-64 code generation, native executable | ✅ **done** |

Verified end to end from a clean checkout: `lumi build examples\fib.lumi` produces
a Windows executable in one command, and its output is byte-for-byte what the
virtual machine prints.

```
$ lumi run   examples\fib.lumi        $ lumi build examples\fib.lumi --output=fib.exe
Fibonacci:                            Fibonacci:
fib(20) is correct                    fib(20) is correct
0 1 1 2 3 5 8 13 21 34                0 1 1 2 3 5 8 13 21 34
```

### What M0 delivers

* A compiler skeleton that builds, runs and reports errors
* **The diagnostic system** -- the focus of M0. Source snippets, carets, multiple
  labels, display-width alignment for wide characters, and colour, in the style
  of rustc
* A command-line driver with `check / tokens / ast / run / build`
* `--selftest`: renders eight representative diagnostics at once, for eyeballing
  the layout

### What M1a delivers

* **A lexer** supporting:
  * decimal, `0x` hexadecimal and `0b` binary literals, with `_` digit separators
  * fractions and exponents
  * string escapes (`\n \t \r \0 \\ \" \'` and `\u{...}` codepoints)
  * `//` line comments and `/* */` block comments
  * non-ASCII identifiers, without the lexer needing to decode UTF-8 at all
* Precise diagnostics for seven classes of lexical error (`L0101`-`L0107`), all
  of which are found **in a single run** -- lexing recovers and continues, so
  you do not have to fix one error to see the next
* `lumi tokens` plus `--dump-tokens` / `--dump-offsets` to inspect the result

Measured: `examples/lex_error.lumi` contains eight different errors, and one
`lumi check` reports all of them with exact positions.

### Two lessons from the lexer

**1. Error recovery has grades, and test cases must respect them.**
An unterminated block comment swallows the rest of the file, so any error after
it is unreachable. `examples/lex_error.lumi` is therefore ordered deliberately:
recoverable errors first, the file-swallowing one last. Otherwise "expose many
problems in one run" quietly stops being true.

**2. You cannot report an error inside a string and return immediately.**
The first version reported and returned on the spot for every problem. Scanning
then stopped mid-string, the closing quote was never consumed, and the lexer
promptly reported "unterminated string literal" as well -- but the quote was
right there. Two contradictory errors leave the reader with no idea which to
believe. The current code scans the whole string, records the first error, and
reports once at the end: the position always ends up past the string, and one
string yields at most one diagnostic.

### What M1b delivers

* **A recursive-descent parser** producing the syntax tree in `ast/ast.h`, with:
  * functions, parameters, `if`/`else`, `while`, `let`/`var`, `return`, `break`,
    `continue`
  * the full expression grammar: calls, unary and binary operators, assignment
    and compound assignment, blocks and `if` as expressions
  * top-level bindings, which become globals
* **Precedence climbing** driven by one operator table, so adding an operator is
  one table row rather than a new tier of recursive functions
* `lumi ast` and `--locations`, which print the tree with source positions

Measured: `examples/parse_error.lumi` holds eight different syntax mistakes and
one `lumi check` reports all eight, with no cascading noise.

### Four lessons from the parser and analyser

**1. Recovery must know what it is skipping.**
After a broken declaration, the recovery routine skipped to the next plausible
statement start -- which landed *inside* the failed function's body. Every
statement there was then reported a second time as an illegal top-level
declaration. The fix is to treat a `{` as the start of the failed declaration's
body and skip the whole balanced block, rather than stopping inside it.

**2. A span doubles as a flag, so a failure has to clear it.**
`TypeNode::span` is valid exactly when a type annotation was written, and callers
test it for that. Returning a node carrying the *current token's* span on failure
therefore claimed success, and the caller pressed on with a half-parsed
declaration. One accurate report turned into a cascade of bogus ones. On failure
the span must be left invalid.

**3. If a brace can be escaped, the matching brace must be too.**
Message templates escape `{{` to a literal `{`, but nothing escaped `}}`. A
message that wanted to print `}` had no way to say so, and the doubled brace
survived into the output as `}}`.

**4. A type assigned on failure is a lie that spreads.**
An `if` with no `else` used as a value was given the type `Unit`. That turned one
correct diagnostic into a misleading second one: the next use of the value failed
with "cannot add i64 and unit", pointing at innocent code. Returning `Unknown`
instead -- a type that is compatible with everything -- lets the single real
diagnostic stand alone. The general rule: when a check fails, the result must be
*unknown*, never a concrete guess.

### What M1c delivers

* **Semantic analysis** resolving every name and computing a type for every
  expression, stored on the AST node so later stages can read it directly
* The rules that need types to check at all:
  * `let` bindings are immutable, and parameters are read-only
  * conditions must be `bool`
  * an `if` used as a value needs an `else` branch, and both branches must agree
  * call arity and argument types
  * no implicit numeric conversions, and `+` doubles as string concatenation
  * `break` and `continue` must be inside a loop
  * every path of a non-unit function must return
  * division by a literal zero, unused bindings, and discarded values (warnings)
* **"Did you mean ...?" suggestions** by edit distance when a name cannot be
  resolved, and a hint to write the comparison out when a condition is not bool
* Built-ins (`print`, `i64_to_str`, `f64_to_str`, `bool_to_str`) are declared in a
  table rather than in Lumi, and are resolved and type checked like anything else

Measured: `examples/sema_error.lumi` breaks thirteen different rules and one
`lumi check` reports all thirteen. `examples/fib.lumi` passes with no output at
all.

### Stage boundaries

Semantic analysis is **skipped entirely when parsing reported errors**.

A tree produced by a failed parse does not describe what the programmer wrote, so
analysing it can only invent problems. A concrete case: the parser rejects
`a < b < c` but still builds `(a < b) < c`, and the analyser then complains that
`<` cannot compare `bool` with `i64` -- pointing at code the user never wrote and
burying the real message. Reporting only the syntax error and stopping is both
quieter and more accurate.

The same idea applies one level down: the lexer reports lexical errors and the
parser still runs, because its recovery is good enough to find genuine syntax
errors afterwards. The distinction is whether the *next* stage can trust what it
is given, not a blanket rule.

## Getting started

```powershell
# Build. The script locates CMake and MSVC on its own.
powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1

# See what the diagnostics look like
.\build\bin\lumi.exe --selftest

# Render one representative diagnostic
.\build\bin\lumi.exe --demo 2

# Compile a source file (during M1 this lexes it and reports token counts)
.\build\bin\lumi.exe check .\examples\fib.lumi
```

> **Why `-ExecutionPolicy Bypass`?**
> The execution policy on this machine blocks running `.ps1` files outright.
> `-ExecutionPolicy Bypass` applies only to this one invocation and does not
> change any system setting.

## Layout

```
lumi/
├── CMakeLists.txt              top-level build script
├── include/lumi/
│   ├── ast/
│   │   ├── ast.h               syntax tree nodes (Expr / Stmt / Program)
│   │   └── printer.h           tree printer used by `lumi ast`
│   ├── diag/
│   │   ├── source.h            source files: loading, offset <-> line/column
│   │   └── diagnostic.h        diagnostic ids, message table, reporting API
│   ├── lexer/
│   │   ├── token.h             TokenKind and Token
│   │   └── lexer.h             lexer interface
│   ├── parser/
│   │   └── parser.h            recursive-descent parser
│   ├── sema/
│   │   └── sema.h              semantic analysis and type checking
│   ├── codegen/
│   │   ├── value.h             the runtime value type
│   │   ├── bytecode.h          instruction set and module layout
│   │   └── emitter.h           syntax tree -> bytecode
│   ├── vm/
│   │   └── vm.h                the stack virtual machine
│   └── support/
│       ├── utf8.h              UTF-8 decoding and display width
│       └── terminal.h          capability probing, colour, UTF-8 output channel
├── src/
│   ├── main.cpp                command-line driver and built-in demo diagnostics
│   ├── ast/
│   │   ├── ast.cpp             node descriptions and operator names
│   │   └── printer.cpp         the tree printer used by `lumi ast`
│   ├── diag/
│   │   ├── source.cpp
│   │   └── diagnostic.cpp      message table and error rendering
│   ├── lexer/
│   │   ├── token.cpp           token naming and debug output
│   │   └── lexer.cpp           the scanner itself
│   ├── parser/
│   │   └── parser.cpp
│   ├── sema/
│   │   └── sema.cpp
│   ├── codegen/
│   │   ├── value.cpp
│   │   ├── bytecode.cpp        opcode names and the disassembler
│   │   └── emitter.cpp
│   ├── vm/
│   │   └── vm.cpp              the interpreter loop
│   └── support/
│       ├── utf8.cpp
│       └── terminal.cpp
├── examples/
│   ├── fib.lumi                the acceptance test (M3 must also run it)
│   ├── vm_test.lumi            thirty independent VM checks
│   ├── lex_test.lumi           every lexer feature, valid and borderline
│   ├── lex_error.lumi          lexical errors, for diagnostic quality
│   ├── parse_error.lumi        syntax errors, for diagnostic quality
│   └── sema_error.lumi         thirteen semantic errors, one per rule
└── scripts/build.ps1
```

## M3: x86-64 native code generation

**It works.** `lumi build` compiles a Lumi program to x86-64 assembly, assembles
it with ml64, links it with link.exe against a runtime written in C, and produces
a Windows executable. The native `fib(20)` prints byte-for-byte what the virtual
machine prints:

```
Fibonacci:
fib(20) is correct
0 1 1 2 3 5 8 13 21 34
```

### Three bugs worth naming

**1. A callee overwrites its caller's temporaries.** Temporaries were addressed
as `-(frame_size + 8*(depth+1))`, which put them *below* rsp. On Windows x64 a
callee's shadow space and frame begin exactly at rsp, so every call trampled the
values its caller had parked there. `fib(n-1)` was destroyed by the call to
`fib(n-2)`, and `fib(20)` printed `140696001646804`.

The fix is placement, not arithmetic: temporaries now sit directly *above* the
shadow space, inside the frame, where no callee reaches.

**2. The frame size was baked into every instruction.** Slot offsets depend on the
frame size, and the frame size depends on how deeply evaluation nests -- which is
only known after the body has been generated. Sizing it from a guess and patching
the prologue afterwards changed the frame while leaving every emitted offset
pointing outside it.

Fixed by breaking the dependency: the body is generated into its own buffer,
temporary slots are named (`fib_TEMP_0 equ 40`) rather than computed, and the
prologue is written last, once the frame size is known.

**3. `equ` symbols are global to the file.** Reusing `LUMI_TEMP_0` in each function
is a redefinition error, so the names carry the function's name.

### The remaining defect

**Fixed.** `lumi build` previously produced working assembly but failed at the
assembler-and-link step, reporting `LNK1181: cannot open input file '.obj'`.

The root cause was a single line of type information: `NativeBuildRequest` carried
its paths as `std::string`. Handing a narrow string to anything that takes a path
makes MSVC decode those bytes using the ANSI code page, and this project's path is
not representable there, so every character came out wrong. The struct now carries
`std::filesystem::path`, and the whole class of bug disappears with it.

Along the way, two other real defects surfaced:

* `LUMI_RUNTIME_OBJ_PATH` was a **PRIVATE** compile definition on `lumic-core`,
  which does not reach the `lumi` executable that `main.cpp` belongs to. The macro
  was never defined, so the linker was handed an empty runtime path -- reported as
  a missing file called `.obj`, pointing nowhere near the cause. It is PUBLIC now,
  and a missing runtime object is checked for explicitly.
* `std::filesystem::path::string()` **throws** on MSVC when the path is outside the
  ANSI code page. Several call sites were one path component away from that. All of
  them go through `path_to_utf8` / `path_from_utf8` now.

A related trap worth recording: stale `fib.exe` processes from earlier broken
builds held the output file open and made the linker fail with `LNK1104`. The
broken versions looped forever rather than crashing, so they were easy to miss.

### A note on how this went

Almost every fix in this milestone came from finally *reading* the assembler's
error instead of guessing at it. Earlier attempts were made blind -- the tools
write to a console handle, and their output was not being captured -- and several
rounds were spent changing code that was not the problem. Redirecting the output
to a file turned a long stretch of guesswork into a short sequence of definite
answers.

The same lesson applies to the path work: printing the actual command line, and
the actual path, ended each round of guessing immediately. The compiler now does
this on request through `LUMI_TOOL_DEBUG`.

### One more bug, found by comparing the two back ends

`examples/hello.lumi` printed this natively:

```
square of 9 is 81     <- the virtual machine
8181                  <- native, before the fix
```

The left operand of a concatenation was being lost. `pop_into` recovered a parked
value by trusting a running depth counter, and that counter is not reliable across
an arbitrary sub-expression: generating the right-hand side runs it down and back
up inside itself, and any call resets it outright. When it came back as zero,
`pop_into` emitted `mov rcx, rax` -- handing the right-hand string in as the left
operand too.

The fix is to stop inferring. Every site that parks a value now captures the slot
index *before* generating anything, and fetches the value back by that index.

What found it was running the same program through both back ends and comparing
the output line by line. That should be a test rather than an observation, which
is the first item under Next.

## Lumi Studio

`build\bin\lumistudio.exe` is a small native editor, so that writing and running
a program does not need a terminal, a file manager and a text editor open at once.
It never links the compiler: it writes the buffer to a temporary file and runs
`lumi.exe` on it, which keeps the two independently buildable.

```
+--------------------------------------------------+
|  Check   Run   Build   Clear                     |
+--------------------------------------------------+
|  code pane    (monospaced, syntax highlighted)   |
+--------------------------------------------------+
|  output pane  (colour-coded: errors, warnings)   |
+--------------------------------------------------+
|  status: what just happened, and how long it took|
+--------------------------------------------------+
```

`Ctrl+Enter` is the whole idea in one keystroke.

### Testing a GUI without a person

A window cannot be checked from a script by looking at it, and "it compiled" says
nothing about whether the rich edit control loaded or the buttons were created.
`lumistudio --selftest` therefore builds the real menu and every real control in a
real window, moved off-screen, and reports what happened:

```
  ok    Msftedit.dll loads
  ok    window class registers
  ok    the Run button exists
  ok    highlighting runs over the sample without faulting
  ok    the compiler starts
  ok    the sample program compiles and runs
  ok    the program's own output comes back through the editor

all checks passed
```

The last three are the ones that matter: they run the sample through the compiler
exactly as the Run button does. Without them the test would prove only that a
window exists.

Results are written to `lumistudio_selftest.log` beside the executable as well as
to the console, because a GUI program is not always given a console to write to --
which is how the first version of this test managed to fail while printing nothing
at all.

That test found a real bug immediately: a rich edit control stores line breaks as
CRLF whatever was put into it, so reading the buffer back did not return what had
been written. `window_text` normalises now.

### Where the program is put before running it

The compiler is handed a file, so the buffer has to land on disk first. Several
folders could serve and none is dependable on every machine, so they are tried in
order and each is tested by *writing to it* rather than by asking whether it
exists:

```
%LOCALAPPDATA%\LumiStudio      ->  the editor's own folder beside the executable
                                ->  %USERPROFILE%\Documents
                                ->  the temporary directory
```

The distinction matters. `GetTempPathW` reports the TEMP variable and never checks
that the directory is really there, and a directory can exist while refusing
writes. The first version used the temporary path alone and reported only
"cannot write the program to a temporary file" -- naming neither the folder nor
the reason, which left the reader with nothing to act on.

The second version fixed that and still did not work, for a reason worth recording:
the folder was chosen carefully in one file and then **ignored in another**.
`run_process` collected the compiler's output by calling `GetTempPathW` for itself,
so the editor found a folder it could write to, wrote the program there, and then
failed to create the file that captures the output next to it. The lesson is not
about temporary directories; it is that a decision made in one place has to be
passed to the other places that depend on it, rather than re-derived.

Both now take the folder that was actually verified. The chosen folder is printed
by `--selftest`, so it can be checked rather than assumed:

```
ok    a writable folder was found for the program
        using E:\deepseek的工作区吖\lumi\build\bin
```

### Diagnosing a GUI that will not say what is wrong

When the Run button failed, there was nothing to inspect: the failure happened
inside a windowed program with no console. Two things made it findable.

`lumistudio --action=run` runs the exact code path the button takes and prints
every step -- which folder, which file, which command, and the compiler's complete
output. `diagnose.bat` wraps that together with the paths on the machine into one
report.

That only worked once the reporting itself was fixed. A GUI program is given no
console, and the usual answer -- attach to the parent's and write to `CONOUT$` --
**bypasses any redirection**: the text goes to the screen while the file the caller
asked for stays empty. Taking the inherited stdout when it is already a file, and
only falling back to the console otherwise, is what made the output visible at all.

## Next

1. Run both back ends over the same suite and diff the results automatically, so a
   divergence between them is a failing test rather than something to notice by
   eye. `examples/hello.lumi` exists because a hand comparison found a real bug.
2. Extend native support to floats: `xmm0`-`xmm3` are reserved in the design but
   the backend still passes every argument in an integer register, so `f64` works
   on the VM only.
3. Give the native backend the rest of the builtins, so `vm_test.lumi` can be
   built as well as run.

## Language sketch

```
let immutable = 1          // let: immutable binding
var mutable = 0            // var: mutable binding
fn name(arg: i64) -> i64 { ... }
if / else / while
// line comment
/* block comment */
```

The guiding principle is **small and correct**: not many features, but each one
cleanly handled at every stage of the compiler.

* Types appear only in function signatures; locals are inferred
* No classes or inheritance, at least not in the first phase
* `if` is an expression; a block has a value taken from its trailing expression
* Identifiers may be non-ASCII, which is why columns are counted as characters
  while carets are positioned by display width

## Diagnostic ids

Ids are a stable interface, formatted as `L` plus four digits.

| Range | Stage |
|---|---|
| L00xx | driver / command line |
| L01xx | lexer |
| L02xx | parser |
| L03xx | semantic analysis |
| L04xx | code generation |
| L05xx | virtual machine runtime |

Each enumerator's value equals its id (`L0301_UndefinedSymbol = 301`), so the id
doubles as a lookup index and `L0317` in a log maps straight onto the
enumerator in the source.

Two `static_assert`s in `src/diag/diagnostic.cpp` guard the table: ids must be
strictly increasing and unique, and every `DiagId` must have a message entry.
A missing entry fails at **compile time** rather than surfacing as
"unknown diagnostic" at runtime.

## Build environment

The combination verified on this machine:

| Component | Version | Location |
|---|---|---|
| MSVC | 14.51 (VS 18) | `D:\Visual Studio\Visual Studio` |
| CMake | 4.4.0 | `C:\Program Files\CMake` |

A fallback: GCC 13.2.0 lives at `E:\myccr\plugin\mingw32\bin`. (The GCC 4.9.2
under `C:\Program Files (x86)\Dev-Cpp` is too old -- C++11 only -- so do not use
it.)

### Four things that bit us

**1. `vcvars64.bat` is not needed.**
CMake's Visual Studio generator discovers the MSVC toolchain by itself, so there
is no build environment to inject. That matters because injecting one normally
means writing a `.bat` and running it through `cmd.exe`, and **batch files are
parsed using the console code page** -- this project's path is not representable
there, so it would arrive as `E:/deepseek?????/lumi`. Avoiding `cmd.exe` avoids
the whole encoding problem.

**2. PowerShell scripts must be ASCII-only.**
Windows PowerShell 5.1 reads `.ps1` files using the ANSI code page, so non-ASCII
comments in a UTF-8 file without a BOM are mis-decoded into garbage bytes and
break parsing outright. `scripts/build.ps1` is therefore ASCII throughout --
deliberately. Please do not "helpfully" translate it. The compiler's own output
is unaffected; that path is fully English and properly encoded.

**3. `main`'s `argv` cannot carry a non-ASCII path on Windows.**
`argv` is produced by the CRT decoding the command line with the ANSI code page.
Measured on this machine:

```
GetCommandLineW -> 0045 003A ... correct UTF-16 ...      OK
argv            ->  45  3A ... ANSI replacement bytes    already mangled
```

`__wargv` does not help either: it is only populated when the program is linked
with a wide-character entry point (`wmain` / `wmainCRTStartup`), and is `NULL`
under an ordinary `main`.

So `term::utf8_command_line_args()` parses `GetCommandLineW()` directly,
following the `CommandLineToArgvW` backslash and quote rules. The entry point
stays plain `main`, so no CMake or linker settings change.

**4. `std::ifstream` cannot open a non-ASCII path either.**
MSVC's `ifstream` takes a narrow path and interprets it with the ANSI code page,
so a file that plainly exists comes back as `No such file or directory`. On
Windows, `SourceManager::load_file()` uses `CreateFileW` instead, converting the
path to UTF-16 via `utf8::to_utf16()` first.

### Three layers of encoding handling on output

All user-facing compiler text goes through `term::write*`. Never use
`std::cout` directly.

| Situation | Strategy |
|---|---|
| attached to a console | `WriteConsoleW` with UTF-16, sidestepping the code page entirely |
| redirected to a file or pipe | raw UTF-8 bytes |
| colour | probed, and overridable with `--color` / `--no-color` |

Before drawing box glyphs the code probes for Unicode support and degrades to
ASCII (`|`, `-->`) when it is unavailable, so redirected output stays tidy.

### What M2 delivers

* **A bytecode compiler and a stack virtual machine.** `lumi run examples/fib.lumi`
  computes `fib(20)` and prints the first ten terms:

  ```
  Fibonacci:
  fib(20) is correct
  0 1 1 2 3 4 ... 34
  ```

* Instruction set: constants, locals and globals, arithmetic, comparison,
  short-circuit logical operators, string concatenation, calls and builtins,
  jumps and returns
* Values are a **tagged union**, not three parallel stacks. See the note below.
* `--dump-bytecode` prints a readable disassembly, which is what makes a wrong
  instruction findable at all
* Runtime errors are reported as diagnostics with the function and instruction:
  division by zero, operand type mismatches, stack underflow, call depth and
  instruction limits

Measured: `examples/vm_test.lumi` runs thirty independent checks covering
arithmetic, floats, strings, `break`/`continue`, nested loops, short-circuit
evaluation, compound assignment, early return and `else if` chains. All thirty
pass; each prints its own label, so a failure names itself.

### Why one tagged value instead of three stacks

Splitting values across separate int/float/string stacks is faster and is what a
serious VM does -- unboxed operands with a computed goto. It also makes every
instruction responsible for remembering which stack its operands came from, and a
mistake there produces the worst kind of bug: silently reading the wrong value,
with nothing to point at.

One tagged `Value` keeps the machine honest. Every push and pop is type-checked in
one place, and a mismatched stack becomes a clean runtime error instead of a wrong
answer. Fibonacci does not care about the difference in speed.

Instructions are also fixed-width rather than a packed byte stream. A packed
encoding is smaller and is what a real compiler emits, but it forces every jump
target through a fix-up pass. Fixed width keeps the generator a single
straightforward walk and makes the disassembly readable.

### Two lessons from the code generator

**1. Every expression must leave exactly one value, including the awkward ones.**
The rule is easy to state and easy to violate. Two places broke it at once: a
block leaves a value only when it has a trailing expression, and the `else if`
form is wrapped in a statement wrapper that was being compiled as a statement --
pushing the nested `if`'s value and then discarding it. The first produced a
stack underflow that ate a live parameter; the second silently lost the type of
the whole chain. Both are fixed by making each branch say what it actually
leaves, rather than assuming.

**2. A type stored on an AST node can be overwritten; look it up instead.**
Semantic analysis stores each expression's *own* result type on the node. For an
assignment that result is `Unit`, so the assignment target -- a variable whose
type is really `str` -- ends up carrying `Unit` by the time code generation runs.
Testing the target's stored type to decide whether `+` means concatenation
therefore picked the arithmetic path for strings. The emitter now keeps its own
table of variable types, which is what it should have done from the start: the
node records the result of the expression, not the type of what it names.
